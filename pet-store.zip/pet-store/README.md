# Pet Store

A Pen created on CodePen.io. Original URL: [https://codepen.io/Codewithshobhit/pen/NWJGvKX](https://codepen.io/Codewithshobhit/pen/NWJGvKX).

**CodePen Challenge: September 2023**  
Navigation – Complex Navigation
---------  

View in [Full Page](https://codepen.io/jackiezen/full/oNJMOvZ) for best experience

Illustrations by [Icons 8 from Ouch!](https://icons8.com/illustrations)

---

